package com.example.software_i_application;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class Inventory {

    private static ObservableList<Part> allParts = FXCollections.observableArrayList();
    private static ObservableList<Product> allProducts = FXCollections.observableArrayList();

    /**
     * adds a part to the table
     * @param newPart the part to add
     */

    public static void addPart(Part newPart) {
        allParts.add(newPart);
    }

    /**
     * Adds a product to the table
     * @param newProduct the product to add
     */

    public static void addProduct(Product newProduct) {
        allProducts.add(newProduct);
    }

    /**
     * Looks up a part in the table
     * @param partName the part to look up
     * @return the parts matching the search
     */

    public static ObservableList lookupPart(String partName) {
        ObservableList<Part> filteredParts = FXCollections.observableArrayList();
        int index = 0;
        int partListSize = getAllParts().size();
        Part currentPart;

        while (index < partListSize) {
            currentPart = Inventory.getAllParts().get(index);
            if (currentPart.getName().toLowerCase().contains(partName.toLowerCase())) {
                filteredParts.add(currentPart);
            }

            index ++;
        }

        return filteredParts;
    }

    /**
     * Looks up a product in the table
     * @param productName the product to look up
     * @return the products matching the search
     */

    public static ObservableList lookupProduct(String productName) {
        ObservableList<Product> filteredProducts = FXCollections.observableArrayList();
        int index = 0;
        int productListSize = getAllProducts().size();
        Product currentProduct;

        while (index < productListSize) {
            currentProduct = Inventory.getAllProducts().get(index);
            if (currentProduct.getName().toLowerCase().contains(productName.toLowerCase())) {
                filteredProducts.add(currentProduct);
            }

            index ++;
        }

        return filteredProducts;
    }

    /**
     * updates the part data
     * @param index the index of the selected part
     * @param selectedPart the selected part to update
     */

    public static void updatePart(int index, Part selectedPart) {
        Inventory.getAllParts().set(index, selectedPart);

    }

    /**
     * updates the product data
     * @param index the index of the selected product
     * @param newProduct the selected product to update
     */

    public static void updateProduct(int index, Product newProduct) {
        Inventory.getAllProducts().set(index, newProduct);
    }

    /**
     * delete a part from the table
     * @param selectedPart the selected part to delete
     */

    public static void deletePart(Part selectedPart){
        allParts.remove(selectedPart);
    }

    /**
     * deletes a product from the table
     * @param selectedProduct the selected product to delete
     */

    public static void deleteProduct(Product selectedProduct) throws RuntimeException {
        allProducts.remove(selectedProduct);
    }

    /**
     * gets all parts
     * @return all parts in the list
     */

    public static ObservableList<Part> getAllParts() {
        return allParts;
    }

    /**
     * gets all products
     * @return all products in the list
     */

    public static ObservableList<Product> getAllProducts() {
        return allProducts;
    }

}
