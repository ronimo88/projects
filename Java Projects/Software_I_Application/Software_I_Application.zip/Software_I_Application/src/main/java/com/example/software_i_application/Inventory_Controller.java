

package com.example.software_i_application;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javax.swing.*;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

/**
 * JavaDoc Files are in the JavaDoc Folder
 * FUTURE ENHANCEMENT: Add the ability to add and delete multiple parts at once.
 * FUTURE ENHANCEMENT: Add the ability to export data to an external database.
 */

public class Inventory_Controller implements Initializable{

    //Configures the table
    @FXML private TableView<Part> partTableView;
    @FXML private TableColumn<Part, Integer> partIDColumn;
    @FXML private TableColumn<Part, Integer> partNameColumn;
    @FXML private TableColumn<Part, Integer> partInventoryLevelColumn;
    @FXML private TableColumn<Part, Integer> partPriceColumn;
    @FXML private TableView<Product> productTableView;
    @FXML private TableColumn<Product, Integer> productIDColumn;
    @FXML private TableColumn<Product, Integer> productNameColumn;
    @FXML private TableColumn<Product, Integer> productInventoryLevelColumn;
    @FXML private TableColumn<Product, Integer> productPriceColumn;
    @FXML private TextField partSearchBox;
    @FXML private TextField productSearchBox;


    /**
     * Changes scene to part view to add a part
     * @param event button pressed
     * @throws IOException checks for valid view
     */
    public void addPartButtonPressed(ActionEvent event) throws IOException {

        //Changes Scene
        Parent addTableViewParent = FXMLLoader.load(getClass().getResource("Part_View.fxml"));
        Scene addTableViewScene = new Scene(addTableViewParent);

        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

        window.setScene(addTableViewScene);
        window.show();
    }

    /**
     * Changes scene to part view to modify a part
     * @param event modify part button pressed
     * @throws IOException checks if the view name is valid
     */

    public void modifyPartButtonPressed(ActionEvent event) throws IOException {

        String partClass = "";
        Part selectedPart = null;
        //InHouse selectedInHousePart = null;
       // Outsourced selectedOutsourcedPart = null;

        //Transfers selected part info to next scene
        ObservableList<Part> selectedRows;
        selectedRows = partTableView.getSelectionModel().getSelectedItems();
        for (Part part: selectedRows) {
            selectedPart = part;

            if (selectedPart.getClass().toString().equals("class com.example.software_i_application.InHouse")) {
                partClass = "inHouse";
            } else {
                partClass = "outsourced";

            }
        }

        if (selectedPart != null) {

            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("Part_View.fxml"));
            Parent viewParent = loader.load();

            Scene viewScene = new Scene(viewParent);

            Part_Controller controller = loader.getController();
            int index = Inventory.getAllParts().indexOf(selectedPart);
            controller.setValues(index, partClass);

            //Loads the new scene
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

            window.setScene(viewScene);
            window.show();
        }
    }

    /**
     * Changes scene to product view to modify a product
     * @param event modify product button pressed
     * @throws IOException checks if the view name is valid
     */

    public void modifyProductButtonPressed(ActionEvent event) throws IOException {

        Product selectedProduct = null;

        //Transfers selected part info to next scene
        ObservableList<Product> selectedRows;
        selectedRows = productTableView.getSelectionModel().getSelectedItems();
        for (Product product: selectedRows) {
            selectedProduct = product;
        }

        if (selectedProduct != null) {

            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(getClass().getResource("Product_View.fxml"));
            Parent viewParent = loader.load();

            Scene viewScene = new Scene(viewParent);

            Product_Controller controller = loader.getController();
            int index = Inventory.getAllProducts().indexOf(selectedProduct);
            controller.setValues(index);

            //Loads the new scene
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

            window.setScene(viewScene);
            window.show();
        }
    }

    /**
     * Deletes part from table
     * RUNTIME ERROR: Received a RUNTIME ERROR after deleting the last item. Inserted a 'break' to stop the 'for loop' for iterating again. Applied this fix to all part and product deletions.
     */

    public void deletePartButtonPressed() {

        ObservableList<Part> selectedRows;
        selectedRows = partTableView.getSelectionModel().getSelectedItems();

        for (Part selectedPart: selectedRows) {
            int input = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete this part?", "", JOptionPane.YES_NO_OPTION);
            if (input == 0) Inventory.deletePart(selectedPart);
            break;
        }
    }

    /**
     * Deletes product from table
     */

    public void deleteProductButtonPressed() {
        ObservableList<Product> selectedRows;
        selectedRows = productTableView.getSelectionModel().getSelectedItems();

        for (Product selectedProduct: selectedRows) {
            if (selectedProduct.getAllAssociatedParts().isEmpty()) {
                int input = JOptionPane.showConfirmDialog(null, "Are you sure you want to delete this product?", "", JOptionPane.YES_NO_OPTION);
                if (input == 0) Inventory.deleteProduct(selectedProduct);
            } else {
                JOptionPane.showMessageDialog(null, "This product has parts. Unable to delete.");
            }
            break;
        }
    }

    /**
     * changes to add part view
     * @param event add button pressed
     * @throws IOException checks if the view name is valid
     */


    public void addProductButtonPressed(ActionEvent event) throws IOException {

        //Changes Scene
        Parent addTableViewParent = FXMLLoader.load(getClass().getResource("Product_View.fxml"));
        Scene addTableViewScene = new Scene(addTableViewParent);

        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

        window.setScene(addTableViewScene);
        window.show();
    }

    /**
     * Exits the application
     */


    public void exitButtonPressed() {
        System.exit(0);
    }

    /**
     * searches for matching parts in the table
     */


    public void partSearchBoxChanged () {
        ObservableList<Part> filteredParts;
        filteredParts = Inventory.lookupPart(partSearchBox.getText());
        partTableView.setItems(filteredParts);

        if (filteredParts.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No Parts Found");
        }
    }

    /**
     * searches for matching products in the table
     */


    public void productSearchBoxChanged () {
        ObservableList<Product> filteredProducts;
        filteredProducts = Inventory.lookupProduct(productSearchBox.getText());

        if (filteredProducts.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No Products Found");
        }
    }

    /**
     * Initializes the inventory tables
     * @param url URL
     * @param rb resource bundle
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        partIDColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        partNameColumn.setCellValueFactory(new PropertyValueFactory<> ("name"));
        partInventoryLevelColumn.setCellValueFactory(new PropertyValueFactory<> ("stock"));
        partPriceColumn.setCellValueFactory(new PropertyValueFactory<> ("price"));
        partTableView.setItems(Inventory.getAllParts());


        productIDColumn.setCellValueFactory(new PropertyValueFactory<> ("id"));
        productNameColumn.setCellValueFactory(new PropertyValueFactory<> ("name"));
        productInventoryLevelColumn.setCellValueFactory(new PropertyValueFactory<> ("stock"));
        productPriceColumn.setCellValueFactory(new PropertyValueFactory<> ("price"));
        productTableView.setItems(Inventory.getAllProducts());
    }
}

