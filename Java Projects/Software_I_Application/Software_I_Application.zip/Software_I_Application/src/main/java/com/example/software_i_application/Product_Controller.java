package com.example.software_i_application;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import javax.swing.*;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import static java.lang.Integer.parseInt;

public class Product_Controller implements Initializable {

    @FXML private TextField nameTextField;
    @FXML private TextField priceTextField;
    @FXML private TextField invTextField;
    @FXML private TextField maxTextField;
    @FXML private TextField minTextField;

    //Configures the table
    @FXML private TableView<Part> partTableView;
    @FXML private TextField iDTextField;
    @FXML private TableColumn<Part, Integer> partIDColumn;
    @FXML private TableColumn<Part, String> partNameColumn;
    @FXML private TableColumn<Part, Integer> partInventoryLevelColumn;
    @FXML private TableColumn<Part, Double> partPriceColumn;
    @FXML private TableView<Part> associatedPartTableView;
    @FXML private TableColumn<Part, Integer> associatedPartIDColumn;
    @FXML private TableColumn<Part, String> associatedPartNameColumn;
    @FXML private TableColumn<Part, Integer> associatedPartInventoryLevelColumn;
    @FXML private TableColumn<Part, Double> associatedPartPriceColumn;
    @FXML private TextField partSearchBox;

    @FXML private Label titleLabel;

    private Product newProduct  = new Product(1,"",0,0,0,0);
    private int productIndex = -1;

    /**
     * Sets the values of the text boxes when modifying a part
     * @param index index of the part
     */

    public void setValues(int index) {

        productIndex = index;

        titleLabel.setText("Modify Part");

        newProduct = Inventory.getAllProducts().get(index);
        associatedPartTableView.setItems(newProduct.getAllAssociatedParts());

        iDTextField.setText(String.valueOf(newProduct.getId()));
        nameTextField.setText(String.valueOf(newProduct.getName()));
        priceTextField.setText(String.valueOf(newProduct.getPrice()));
        invTextField.setText(String.valueOf(newProduct.getStock()));
        minTextField.setText(String.valueOf(newProduct.getMin()));
        maxTextField.setText(String.valueOf(newProduct.getMax()));

    }

    /**
     * searches for matching parts in the table
     */

    public void partSearchBoxChanged () {
        ObservableList<Part> filteredParts = FXCollections.observableArrayList();
        filteredParts = Inventory.lookupPart(partSearchBox.getText());
        partTableView.setItems(filteredParts);

        if (filteredParts.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No Parts Found");
        }
    }

    /**
     * Adds part to associated parts table
     */

    public void addButtonPressed() {


        ObservableList<Part> selectedRows;
        selectedRows = partTableView.getSelectionModel().getSelectedItems();
        for (Part selectedPart: selectedRows) {
            newProduct.addAssociatedPart(selectedPart);
        }

        associatedPartTableView.setItems(newProduct.getAllAssociatedParts());

    }

    /**
     * removes associated part from the table
     */

    public void removeAssociatedPartButtonPressed() {
        ObservableList<Part> selectedRows;
        selectedRows = associatedPartTableView.getSelectionModel().getSelectedItems();
        for (Part selectedPart: selectedRows) {
            int input = JOptionPane.showConfirmDialog(null, "Are you sure you want to remove this associated part?", "", JOptionPane.YES_NO_OPTION);
            if (input == 0) newProduct.deleteAssociatedPart(selectedPart);
            break;
        }

        associatedPartTableView.setItems(newProduct.getAllAssociatedParts());
    }

    /**
     * cancels and returns to inventory view
     * @param event cancel button pressed
     * @throws IOException checks if the view name is valid
     */

    public void cancelButtonPressed(ActionEvent event) throws IOException {
        Parent viewParent = FXMLLoader.load(getClass().getResource("Inventory_View.fxml"));
        Scene viewScene = new Scene(viewParent);

        //Gets stage info
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

        window.setScene(viewScene);
        window.show();
    }

    /**
     * adds or modifies a product
     * @param event save button pressed
     * @throws IOException checks if the view name is valid
     */

    public void saveButtonPressed(ActionEvent event) throws IOException {

        String name;
        double price = 0;
        int stock = 0;
        int min = 0;
        int max = 0;

        String exceptionText = "";

        name = nameTextField.getText();

        try {

            price = Double.parseDouble(priceTextField.getText());

        } catch (NumberFormatException e) {

            exceptionText += "Price is not a double\n";

        } try {

            stock = parseInt(invTextField.getText());

        } catch (NumberFormatException e) {

            exceptionText += "Stock is not an integer\n";

        } try {

            min = parseInt(minTextField.getText());

        } catch (NumberFormatException e) {

            exceptionText += "Min is not an integer\n";

        } try {

            max = parseInt(maxTextField.getText());

        } catch  (NumberFormatException e) {

            exceptionText += "Max is not an integer\n";

        }

        if (exceptionText.equals("")) {
            if (max < min)
                exceptionText += "Min cannot be greater than max \n";

            if (price < min || price > max)
                exceptionText += "Price has to be between min and max\n";
        }


        if (exceptionText.equals("")) {

            newProduct.setName(name);
            newProduct.setPrice(price);
            newProduct.setStock(stock);
            newProduct.setMin(min);
            newProduct.setMax(max);


            if (productIndex == -1) {

                //Adds new part. Sets the id to a number after the last id in the inventory list.


                int id = 1;

                int size = Inventory.getAllProducts().size();

                if (size > 0) {
                    Product lastProduct = Inventory.getAllProducts().get(size - 1);
                    id = lastProduct.getId() + 1;

                }

                newProduct.setId(id);
                Inventory.addProduct(newProduct);

            } else {

                // Modifies part

                int iD = parseInt(iDTextField.getText());
                newProduct.setId(iD);
                Inventory.updateProduct(productIndex, newProduct);


            }

            // Goes back to inventory view


            Parent viewParent = FXMLLoader.load(getClass().getResource("Inventory_View.fxml"));
            Scene viewScene = new Scene(viewParent);

            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

            window.setScene(viewScene);
            window.show();
        } else
            JOptionPane.showMessageDialog(null, "Errors:\n" + exceptionText);
    }

    /**
     * Initializes the table information
     * @param url URL
     * @param rb resource bundle
     */

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        partIDColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        partNameColumn.setCellValueFactory(new PropertyValueFactory<> ("name"));
        partInventoryLevelColumn.setCellValueFactory(new PropertyValueFactory<> ("stock"));
        partPriceColumn.setCellValueFactory(new PropertyValueFactory<> ("price"));
        partTableView.setItems(Inventory.getAllParts());

        associatedPartIDColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        associatedPartNameColumn.setCellValueFactory(new PropertyValueFactory<> ("name"));
        associatedPartInventoryLevelColumn.setCellValueFactory(new PropertyValueFactory<> ("stock"));
        associatedPartPriceColumn.setCellValueFactory(new PropertyValueFactory<> ("price"));

        associatedPartTableView.setItems(newProduct.getAllAssociatedParts());
    }
}
