package com.example.software_i_application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.stage.Stage;

import javax.swing.*;

import static java.lang.Integer.parseInt;

public class Part_Controller implements Initializable {

    @FXML private RadioButton inHouseRadioButton;
    @FXML private RadioButton outsourcedRadioButton;
    @FXML private TextField iDTextField;
    @FXML private TextField nameTextField;
    @FXML private TextField invTextField;
    @FXML private TextField priceTextField;
    @FXML private TextField maxTextField;
    @FXML private TextField minTextField;
    @FXML private TextField machineIDTextField;
    @FXML private Label machineId_label;
    @FXML private Label titleLabel;

    public int partIndex = -1;
    public String partClass;

    InHouse newInHousePart = new InHouse(1, "", 0,0,0,0,0);
    Outsourced newOutsourcedPart = new Outsourced(1, "", 0,0,0,0,"");

    /**
     * Sets the values of the text boxes when modifying a part
     * @param index index of the part
     * @param partClass whether the part is in house or outsourced
     */
    public void setValues(int index, String partClass) {

        partIndex = index;
        this.partClass = partClass;

        if (partClass.equals("outsourced")) {
            outsourcedRadioButton.setSelected(true);
            machineId_label.setText("Company Name");
        }

        titleLabel.setText("Modify Part");

        Part selectedPart = Inventory.getAllParts().get(index);

        iDTextField.setText(String.valueOf(selectedPart.getId()));
        nameTextField.setText(String.valueOf(selectedPart.getName()));
        priceTextField.setText(String.valueOf(selectedPart.getPrice()));
        invTextField.setText(String.valueOf(selectedPart.getStock()));
        minTextField.setText(String.valueOf(selectedPart.getMin()));
        maxTextField.setText(String.valueOf(selectedPart.getMax()));

        if (partClass.equals("inHouse")) {
            newInHousePart = (InHouse) selectedPart;
            machineIDTextField.setText(String.valueOf(newInHousePart.getMachineId()));
        }

        if (partClass.equals("outsourced")) {
            newOutsourcedPart = (Outsourced) selectedPart;
            machineIDTextField.setText(String.valueOf(newOutsourcedPart.getCompanyName()));
        }

    }

    /**
     * Cancels and returns to Inventory View
     */

    public void cancelButtonPressed(ActionEvent event) throws IOException {
        Parent viewParent = FXMLLoader.load(getClass().getResource("Inventory_View.fxml"));
        Scene viewScene = new Scene(viewParent);

        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

        window.setScene(viewScene);
        window.show();
    }


    /**
     * Adds or modifies a part
     * @param event save button pressed
     * @throws IOException checks if the view name is valid
     */

    public void saveButtonPressed(ActionEvent event) throws IOException {

        String name;
        double price = 0;
        int stock = 0;
        int min = 0;
        int max = 0;
        int machineId = 0;
        String companyName;

        name = nameTextField.getText();

        String exceptionText = "";

        try {

            price = Double.parseDouble(priceTextField.getText());

        } catch (NumberFormatException e) {

            exceptionText += "Price is not a double\n";

        } try {

            stock = parseInt(invTextField.getText());

        } catch (NumberFormatException e) {

            exceptionText += "Stock is not an integer\n";

        } try {

            min = parseInt(minTextField.getText());

        } catch (NumberFormatException e) {

            exceptionText += "Min is not an integer\n";

        } try {

            max = parseInt(maxTextField.getText());

        } catch  (NumberFormatException e) {

            exceptionText += "Max is not an integer\n";

        }
        if (inHouseRadioButton.isSelected()) {
            try {
                machineId = parseInt(machineIDTextField.getText());
            } catch (NumberFormatException e) {

                exceptionText += "Machine ID is not an integer\n";
            }
        }

        companyName = machineIDTextField.getText();

        if (max < min)
            exceptionText += "Min cannot be greater than max \n";

        if (price < min || price > max)
            exceptionText += "Price has to be between min and max\n";


        if (exceptionText.equals("")) {

            if (inHouseRadioButton.isSelected()) {

                newInHousePart.setName(name);
                newInHousePart.setPrice(price);
                newInHousePart.setStock(stock);
                newInHousePart.setMin(min);
                newInHousePart.setMax(max);
            } else {

                newOutsourcedPart.setName(name);
                newOutsourcedPart.setPrice(price);
                newOutsourcedPart.setStock(stock);
                newOutsourcedPart.setMin(min);
                newOutsourcedPart.setMax(max);
            }

            if (partIndex == -1) {

                // Sets the id to a number after the last id in the inventory list.


                int id = 1;

                int size = Inventory.getAllParts().size();

                if (size > 0) {
                    Part lastPart = Inventory.getAllParts().get(size - 1);
                    id = lastPart.getId() + 1;
                }

                if (inHouseRadioButton.isSelected()) {

                    newInHousePart.setId(id);
                    newInHousePart.setMachineId(machineId);
                    newOutsourcedPart.setCompanyName(companyName);


                    Inventory.addPart(newInHousePart);
                } else {
                    newInHousePart.setId(id);
                    Inventory.addPart(newOutsourcedPart);
                }

            } else {

                //Modifies the part

                int iD = parseInt(iDTextField.getText());

                if (partClass.equals("inHouse")) {
                    machineId = parseInt(machineIDTextField.getText());
                    //Part selectedPart = Inventory.getAllParts().get(partIndex);
                    InHouse inHousePart = new InHouse(iD, name, price, stock, min, max, machineId);
                    Inventory.updatePart(partIndex, inHousePart);
                } else {
                    companyName = machineIDTextField.getText();
                   // Part selectedPart = Inventory.getAllParts().get(partIndex);
                    Outsourced outsourcedPart = new Outsourced(iD, name, price, stock, min, max, companyName);
                    Inventory.updatePart(partIndex, outsourcedPart);
                }
            }


             // Goes back to inventory view


            Parent viewParent = FXMLLoader.load(getClass().getResource("Inventory_View.fxml"));
            Scene viewScene = new Scene(viewParent);

            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();

            window.setScene(viewScene);
            window.show();
        } else
            JOptionPane.showMessageDialog(null, "Errors:\n" + exceptionText);

    }

    /**
     * Changes part class to Outsourced if outsourced radio button is pressed
     */

    public void outsourcedSelected () {

        machineId_label.setText("Company Name");
        partClass = "outsourced";
        // setValues(partIndex, partClass);
    }

    /**
     * Changes part class to InHouse if In House radio button is pressed
     */

    public void inHouseSelected () {

        machineId_label.setText("Machine ID");
        partClass = "inHouse";
        // setValues(partIndex, partClass);
    }

    /**
     * Initializes the radio buttons
     * @param url URL
     * @param rb resource bundle
     */

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        ToggleGroup addPartToggleGroup = new ToggleGroup();
        this.inHouseRadioButton.setToggleGroup(addPartToggleGroup);
        this.outsourcedRadioButton.setToggleGroup(addPartToggleGroup);

    }




}

