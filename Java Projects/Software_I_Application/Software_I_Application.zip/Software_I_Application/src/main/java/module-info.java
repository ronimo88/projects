module com.example.software_i_application {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.dlsc.formsfx;
    requires java.desktop;

    opens com.example.software_i_application to javafx.fxml;
    exports com.example.software_i_application;
}